import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { verifyAuth } from '@/lib/auth';

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    // Verify authentication
    const user = await verifyAuth(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Get query parameters
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');
    const category = searchParams.get('category');

    // Build where clause based on user role
    const where: any = {
      isActive: true,
    };

    // Role-based filtering
    if (user.role === 'ADMIN') {
      // Admins can only see menu items from their restaurants
      const adminRestaurants = await prisma.restaurant.findMany({
        where: { adminId: user.adminId },
        select: { restaurantId: true },
      });
      
      const restaurantIds = adminRestaurants.map(r => r.restaurantId);
      where.restaurantId = { in: restaurantIds };
    }
    // Super Admin can see all menu items (no additional filtering)

    // Search filter
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    // Category filter
    if (category) {
      where.category = category;
    }

    // Fetch menu items
    const menuItems = await prisma.menuTemplate.findMany({
      where,
      include: {
        restaurant: {
          select: {
            restaurantId: true,
            name: true,
          },
        },
        // Note: category is a scalar field (string), not a relation
        // So we don't include it here - it's already part of the base model
      },
      orderBy: [
        { category: 'asc' },
        { name: 'asc' },
      ],
    });

    // Get unique categories for filtering
    const categories = await prisma.category.findMany({
      where: { isActive: true },
      orderBy: { displayOrder: 'asc' },
      select: {
        categoryId: true,
        name: true,
      },
    });

    return NextResponse.json({
      data: menuItems,
      total: menuItems.length,
      categories,
    });
  } catch (error) {
    console.error('List menus error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch menu items' },
      { status: 500 }
    );
  }
}
