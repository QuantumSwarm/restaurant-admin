// app/api/menus/[id]/route.ts
// Update and delete menu item API endpoints - FIXED for actual schema

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db/prisma';
import { verifyToken } from '@/lib/auth/jwt';

// PUT - Update menu item
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Get token from cookie
    const token = request.cookies.get('token')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Verify token
    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json(
        { error: 'Invalid or expired token' },
        { status: 401 }
      );
    }

    const templateId = parseInt(params.id);

    // Check if menu item exists
    const existingItem = await prisma.menuTemplate.findUnique({
      where: { templateId },
      include: {
        restaurant: true,
      },
    });

    if (!existingItem) {
      return NextResponse.json(
        { error: 'Menu item not found' },
        { status: 404 }
      );
    }

    // Check permission for regular admins
    if (decoded.role !== 'super_admin') {
      if (existingItem.restaurant.adminId !== decoded.adminId) {
        return NextResponse.json(
          { error: 'You do not have permission to edit this item' },
          { status: 403 }
        );
      }
    }

    // Parse request body
    const body = await request.json();
    const {
      name,
      description,
      categoryId,
      basePrice,
      imageUrl,
      calories,
      isActive,
    } = body;

    // Build update data
    const updateData: any = {};

    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (categoryId !== undefined) updateData.categoryId = categoryId ? parseInt(categoryId) : null;
    if (basePrice !== undefined) {
      const price = parseFloat(basePrice);
      if (isNaN(price) || price < 0) {
        return NextResponse.json(
          { error: 'Invalid price value' },
          { status: 400 }
        );
      }
      updateData.basePrice = price;
    }
    if (imageUrl !== undefined) updateData.imageUrl = imageUrl;
    if (calories !== undefined) updateData.calories = calories ? parseInt(calories) : null;
    if (isActive !== undefined) updateData.isActive = isActive;

    // Update menu item
    const updatedItem = await prisma.menuTemplate.update({
      where: { templateId },
      data: updateData,
      include: {
        restaurant: {
          select: {
            name: true,
          },
        },
        category: {
          select: {
            categoryId: true,
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Menu item updated successfully',
      menuItem: updatedItem,
    });
  } catch (error) {
    console.error('Update menu item error:', error);
    return NextResponse.json(
      { error: 'Failed to update menu item' },
      { status: 500 }
    );
  }
}

// DELETE - Soft delete menu item
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Get token from cookie
    const token = request.cookies.get('token')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Verify token
    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json(
        { error: 'Invalid or expired token' },
        { status: 401 }
      );
    }

    const templateId = parseInt(params.id);

    // Check if menu item exists
    const existingItem = await prisma.menuTemplate.findUnique({
      where: { templateId },
      include: {
        restaurant: true,
      },
    });

    if (!existingItem) {
      return NextResponse.json(
        { error: 'Menu item not found' },
        { status: 404 }
      );
    }

    // Check permission for regular admins
    if (decoded.role !== 'super_admin') {
      if (existingItem.restaurant.adminId !== decoded.adminId) {
        return NextResponse.json(
          { error: 'You do not have permission to delete this item' },
          { status: 403 }
        );
      }
    }

    // Soft delete - set isActive to false
    await prisma.menuTemplate.update({
      where: { templateId },
      data: { isActive: false },
    });

    return NextResponse.json({
      success: true,
      message: 'Menu item deleted successfully',
    });
  } catch (error) {
    console.error('Delete menu item error:', error);
    return NextResponse.json(
      { error: 'Failed to delete menu item' },
      { status: 500 }
    );
  }
}
