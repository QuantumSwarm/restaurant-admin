// app/api/stores/[id]/route.ts
// Update and Delete store API endpoints (PUT, DELETE)

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db/prisma';
import { verifyToken } from '@/lib/auth/jwt';

// UPDATE Store
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const storeId = parseInt(params.id);

    // Get token from cookie
    const token = request.cookies.get('token')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Verify token
    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json(
        { error: 'Invalid or expired token' },
        { status: 401 }
      );
    }

    // Get existing store to check permissions
    const existingStore = await prisma.store.findUnique({
      where: { storeId },
      include: { restaurant: true },
    });

    if (!existingStore) {
      return NextResponse.json(
        { error: 'Store not found' },
        { status: 404 }
      );
    }

    // For regular admins, verify they own the restaurant
    if (decoded.role !== 'super_admin') {
      if (existingStore.restaurant.adminId !== decoded.adminId) {
        return NextResponse.json(
          { error: 'You do not have permission to edit this store' },
          { status: 403 }
        );
      }
    }

    // Parse request body
    const body = await request.json();
    const {
      locationId,
      address,
      phonePrimary,
      phoneSecondary,
      isAiAgentEnabled,
      timeZone,
    } = body;

    // Update store
    const updatedStore = await prisma.store.update({
      where: { storeId },
      data: {
        ...(locationId && { locationId: parseInt(locationId) }),
        ...(address && { address }),
        phonePrimary: phonePrimary || null,
        phoneSecondary: phoneSecondary || null,
        ...(isAiAgentEnabled !== undefined && { isAiAgentEnabled }),
        ...(timeZone && { timeZone }),
        updatedAt: new Date(),
      },
      include: {
        restaurant: {
          select: {
            name: true,
          },
        },
        location: {
          select: {
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Store updated successfully',
      store: updatedStore,
    });
  } catch (error) {
    console.error('Update store error:', error);
    return NextResponse.json(
      { error: 'Failed to update store' },
      { status: 500 }
    );
  }
}

// DELETE Store (Soft Delete)
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const storeId = parseInt(params.id);

    // Get token from cookie
    const token = request.cookies.get('token')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Verify token
    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json(
        { error: 'Invalid or expired token' },
        { status: 401 }
      );
    }

    // Get existing store to check permissions
    const existingStore = await prisma.store.findUnique({
      where: { storeId },
      include: { restaurant: true },
    });

    if (!existingStore) {
      return NextResponse.json(
        { error: 'Store not found' },
        { status: 404 }
      );
    }

    // For regular admins, verify they own the restaurant
    if (decoded.role !== 'super_admin') {
      if (existingStore.restaurant.adminId !== decoded.adminId) {
        return NextResponse.json(
          { error: 'You do not have permission to delete this store' },
          { status: 403 }
        );
      }
    }

    // Soft delete by setting isActive to false
    await prisma.store.update({
      where: { storeId },
      data: {
        isActive: false,
        updatedAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Store deleted successfully',
    });
  } catch (error) {
    console.error('Delete store error:', error);
    return NextResponse.json(
      { error: 'Failed to delete store' },
      { status: 500 }
    );
  }
}
