// app/api/stores/route.ts
// List stores API endpoint (GET) - filtered by user role

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db/prisma';
import { verifyToken } from '@/lib/auth/jwt';

export async function GET(request: NextRequest) {
  try {
    // Get token from cookie
    const token = request.cookies.get('token')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Verify token
    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json(
        { error: 'Invalid or expired token' },
        { status: 401 }
      );
    }

    // Get query parameters for filtering/searching
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';

    // Build where clause based on user role
    const where: any = {
      isActive: true,  // Only show active stores
      restaurant: {
        isActive: true,
      },
    };

    // For regular admins, only show their restaurants' stores
    if (decoded.role !== 'super_admin') {
      where.restaurant.adminId = decoded.adminId;
    }

    // Add search filter if provided
    if (search) {
      where.OR = [
        { address: { contains: search, mode: 'insensitive' } },
        { phonePrimary: { contains: search } },
        { location: { name: { contains: search, mode: 'insensitive' } } },
      ];
    }

    // Fetch stores with related data
    const stores = await prisma.store.findMany({
      where,
      include: {
        restaurant: {
          select: {
            restaurantId: true,
            name: true,
          },
        },
        location: {
          select: {
            locationId: true,
            name: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return NextResponse.json({
      success: true,
      stores,
      count: stores.length,
    });
  } catch (error) {
    console.error('List stores error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch stores' },
      { status: 500 }
    );
  }
}
