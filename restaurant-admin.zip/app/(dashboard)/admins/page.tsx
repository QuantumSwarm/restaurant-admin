'use client';

// app/(dashboard)/admins/page.tsx
// Admins management page (Super Admin only)

import React, { useEffect, useState } from 'react';
import { Typography, Alert, Spin } from 'antd';
import { useRouter } from 'next/navigation';
import { getStoredUser, isSuperAdmin } from '@/lib/auth/permissions';

const { Title } = Typography;

export default function AdminsPage() {
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const user = getStoredUser();
    
    if (!isSuperAdmin(user)) {
      router.push('/unauthorized');
      return;
    }
    
    setLoading(false);
  }, [router]);

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: 50 }}>
        <Spin size="large" tip="Checking permissions..." />
      </div>
    );
  }

  return (
    <div>
      <Title level={2}>Admin Management</Title>
      <Alert
        message="Super Admin Access Only"
        description="This page is only accessible to Super Admin users. We'll build the full admin management functionality in Use Case 7."
        type="info"
        showIcon
      />
    </div>
  );
}
