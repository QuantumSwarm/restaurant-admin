"use client";

import { useState } from "react";
import { useTable, useMany } from "@refinedev/core";
import {
  List,
  EditButton,
  DeleteButton,
  ShowButton,
} from "@refinedev/antd";
import { Table, Space, Tag, Input, Select } from "antd";
import { SearchOutlined } from "@ant-design/icons";

const { Search } = Input;

export default function MenuList() {
  const [searchText, setSearchText] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string | undefined>();

  const { tableProps, tableQueryResult } = useTable({
    resource: "menus",
    syncWithLocation: true,
    filters: {
      permanent: [
        ...(searchText ? [{ field: "search", operator: "contains", value: searchText }] : []),
        ...(categoryFilter ? [{ field: "category", operator: "eq", value: categoryFilter }] : []),
      ],
    },
  });

  // Get categories for filter dropdown
  const categories = tableQueryResult?.data?.categories || [];

  // Get restaurant data for each menu item
  const restaurantIds = tableQueryResult?.data?.data?.map((item: any) => item.restaurantId) || [];
  const { data: restaurantsData } = useMany({
    resource: "restaurants",
    ids: restaurantIds,
    queryOptions: {
      enabled: restaurantIds.length > 0,
    },
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price);
  };

  return (
    <List
      headerButtons={({ defaultButtons }) => (
        <>
          <Space>
            <Search
              placeholder="Search menu items..."
              allowClear
              enterButton={<SearchOutlined />}
              onSearch={(value) => setSearchText(value)}
              style={{ width: 300 }}
            />
            <Select
              placeholder="Filter by category"
              allowClear
              style={{ width: 200 }}
              onChange={(value) => setCategoryFilter(value)}
              options={categories.map((cat: any) => ({
                label: cat.name,
                value: cat.name,
              }))}
            />
          </Space>
          {defaultButtons}
        </>
      )}
    >
      <Table {...tableProps} rowKey="menuTemplateId">
        <Table.Column
          dataIndex="name"
          title="Item Name"
          sorter
          render={(value) => <strong>{value}</strong>}
        />
        <Table.Column
          dataIndex="description"
          title="Description"
          ellipsis={{ showTitle: false }}
          width="25%"
        />
        <Table.Column
          dataIndex="category"
          title="Category"
          render={(value) => <Tag color="blue">{value}</Tag>}
          filters={categories.map((cat: any) => ({
            text: cat.name,
            value: cat.name,
          }))}
          onFilter={(value, record: any) => record.category === value}
        />
        <Table.Column
          dataIndex="price"
          title="Base Price"
          align="right"
          render={(value) => formatPrice(value)}
          sorter
        />
        <Table.Column
          dataIndex="restaurantId"
          title="Restaurant"
          render={(value) => {
            const restaurant = restaurantsData?.data?.find(
              (r: any) => r.restaurantId === value
            );
            return restaurant?.name || "N/A";
          }}
        />
        <Table.Column
          dataIndex="isAvailable"
          title="Available"
          align="center"
          render={(value) => (
            <Tag color={value ? "green" : "red"}>
              {value ? "Yes" : "No"}
            </Tag>
          )}
          filters={[
            { text: "Available", value: true },
            { text: "Unavailable", value: false },
          ]}
          onFilter={(value, record: any) => record.isAvailable === value}
        />
        <Table.Column
          title="Actions"
          dataIndex="actions"
          fixed="right"
          width={150}
          render={(_, record: any) => (
            <Space>
              <EditButton
                hideText
                size="small"
                recordItemId={record.menuTemplateId}
              />
              <ShowButton
                hideText
                size="small"
                recordItemId={record.menuTemplateId}
              />
              <DeleteButton
                hideText
                size="small"
                recordItemId={record.menuTemplateId}
                confirmTitle="Are you sure you want to delete this menu item?"
                confirmOkText="Delete"
                confirmCancelText="Cancel"
              />
            </Space>
          )}
        />
      </Table>
    </List>
  );
}
