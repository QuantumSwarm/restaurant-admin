// scripts/create-test-admin.js
// Run this to create a test admin user

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function createTestAdmin() {
  try {
    // Hash the password
    const password = 'password123';
    const passwordHash = await bcrypt.hash(password, 10);

    // Create admin
    const admin = await prisma.admin.create({
      data: {
        email: 'admin@test.com',
        passwordHash: passwordHash,
        role: 'super_admin',
        isActive: true,
      },
    });

    console.log('✅ Test admin created successfully!');
    console.log('Email:', admin.email);
    console.log('Password: password123');
    console.log('Role:', admin.role);
  } catch (error) {
    if (error.code === 'P2002') {
      console.log('⚠️  Admin already exists. Updating password...');
      
      // Update existing admin
      const password = 'password123';
      const passwordHash = await bcrypt.hash(password, 10);
      
      await prisma.admin.update({
        where: { email: 'admin@test.com' },
        data: { passwordHash: passwordHash, isActive: true },
      });
      
      console.log('✅ Password updated!');
      console.log('Email: admin@test.com');
      console.log('Password: password123');
    } else {
      console.error('Error creating admin:', error);
    }
  } finally {
    await prisma.$disconnect();
  }
}

createTestAdmin();
