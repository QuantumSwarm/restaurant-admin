'use client';

// components/menus/MenuModal.tsx
// Modal for creating/editing menu items - FIXED for actual schema

import React, { useState, useEffect } from 'react';
import {
  Modal,
  Form,
  Input,
  InputNumber,
  Select,
  Switch,
  message,
  Spin,
} from 'antd';

const { TextArea } = Input;

interface MenuItem {
  templateId: number;
  name: string;
  description: string | null;
  categoryId: number | null;
  basePrice: number;
  imageUrl: string | null;
  calories: number | null;
  isActive: boolean;
  restaurant: {
    restaurantId: number;
    name: string;
  };
  category?: {
    categoryId: number;
    name: string;
  } | null;
}

interface Restaurant {
  restaurantId: number;
  name: string;
}

interface Category {
  categoryId: number;
  name: string;
  displayOrder: number;
}

interface MenuModalProps {
  visible: boolean;
  mode: 'create' | 'edit';
  menu?: MenuItem;
  onClose: () => void;
  onSuccess: () => void;
}

export default function MenuModal({
  visible,
  mode,
  menu,
  onClose,
  onSuccess,
}: MenuModalProps) {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [fetchingRestaurants, setFetchingRestaurants] = useState(false);
  const [fetchingCategories, setFetchingCategories] = useState(false);
  const [messageApi, contextHolder] = message.useMessage();

  // Fetch restaurants for the dropdown
  const fetchRestaurants = async () => {
    setFetchingRestaurants(true);
    try {
      const response = await fetch('/api/restaurants');
      const data = await response.json();

      if (response.ok && data.success) {
        setRestaurants(data.restaurants);
      } else {
        messageApi.error('Failed to fetch restaurants');
      }
    } catch (error) {
      console.error('Fetch restaurants error:', error);
      messageApi.error('An error occurred while fetching restaurants');
    } finally {
      setFetchingRestaurants(false);
    }
  };

  // Fetch categories for the dropdown
  const fetchCategories = async () => {
    setFetchingCategories(true);
    try {
      const response = await fetch('/api/categories');
      const data = await response.json();

      if (response.ok && data.success) {
        setCategories(data.categories);
      } else {
        messageApi.error('Failed to fetch categories');
      }
    } catch (error) {
      console.error('Fetch categories error:', error);
      messageApi.error('An error occurred while fetching categories');
    } finally {
      setFetchingCategories(false);
    }
  };

  // Load restaurants and categories on mount
  useEffect(() => {
    if (visible) {
      fetchRestaurants();
      fetchCategories();
    }
  }, [visible]);

  // Set form values when editing
  useEffect(() => {
    if (visible && mode === 'edit' && menu) {
      form.setFieldsValue({
        restaurantId: menu.restaurant.restaurantId,
        name: menu.name,
        description: menu.description,
        categoryId: menu.categoryId,
        basePrice: menu.basePrice,
        imageUrl: menu.imageUrl,
        calories: menu.calories,
        isActive: menu.isActive,
      });
    } else if (visible && mode === 'create') {
      form.resetFields();
      form.setFieldsValue({
        isActive: true,
      });
    }
  }, [visible, mode, menu, form]);

  // Handle form submission
  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      const url =
        mode === 'create'
          ? '/api/menus/create'
          : `/api/menus/${menu?.templateId}`;

      const method = mode === 'create' ? 'POST' : 'PUT';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        messageApi.success(
          mode === 'create'
            ? 'Menu item created successfully'
            : 'Menu item updated successfully'
        );
        form.resetFields();
        onSuccess();
        onClose();
      } else {
        messageApi.error(data.error || 'Operation failed');
      }
    } catch (error: any) {
      if (error?.errorFields) {
        // Form validation errors - don't show a message, form will show inline errors
        return;
      }
      console.error('Submit error:', error);
      messageApi.error('An error occurred while saving');
    } finally {
      setLoading(false);
    }
  };

  // Handle cancel
  const handleCancel = () => {
    form.resetFields();
    onClose();
  };

  const isLoading = fetchingRestaurants || fetchingCategories;

  return (
    <>
      {contextHolder}
      <Modal
        title={mode === 'create' ? 'Add Menu Item' : 'Edit Menu Item'}
        open={visible}
        onOk={handleSubmit}
        onCancel={handleCancel}
        confirmLoading={loading}
        width={600}
        okText={mode === 'create' ? 'Create' : 'Update'}
        cancelText="Cancel"
      >
        <Spin spinning={isLoading}>
          <Form
            form={form}
            layout="vertical"
            style={{ marginTop: 24 }}
            autoComplete="off"
          >
            {/* Restaurant Selection */}
            <Form.Item
              label="Restaurant"
              name="restaurantId"
              rules={[
                { required: true, message: 'Please select a restaurant' },
              ]}
            >
              <Select
                placeholder="Select restaurant"
                size="large"
                disabled={mode === 'edit'} // Can't change restaurant when editing
                showSearch
                optionFilterProp="children"
                filterOption={(input, option) =>
                  (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                }
                options={restaurants.map((r) => ({
                  value: r.restaurantId,
                  label: r.name,
                }))}
              />
            </Form.Item>

            {/* Name */}
            <Form.Item
              label="Name"
              name="name"
              rules={[
                { required: true, message: 'Please enter item name' },
                { max: 100, message: 'Name must be at most 100 characters' },
              ]}
            >
              <Input
                placeholder="e.g., Caesar Salad"
                size="large"
                maxLength={100}
              />
            </Form.Item>

            {/* Category */}
            <Form.Item
              label="Category"
              name="categoryId"
              rules={[{ required: false, message: 'Please select a category' }]}
            >
              <Select
                placeholder="Select category (optional)"
                size="large"
                allowClear
                options={categories.map((cat) => ({
                  value: cat.categoryId,
                  label: cat.name,
                }))}
              />
            </Form.Item>

            {/* Base Price */}
            <Form.Item
              label="Base Price"
              name="basePrice"
              rules={[
                { required: true, message: 'Please enter base price' },
                {
                  type: 'number',
                  min: 0,
                  message: 'Price must be a positive number',
                },
              ]}
            >
              <InputNumber
                placeholder="0.00"
                size="large"
                style={{ width: '100%' }}
                precision={2}
                min={0}
                prefix="$"
                step={0.5}
              />
            </Form.Item>

            {/* Description */}
            <Form.Item
              label="Description"
              name="description"
            >
              <TextArea
                placeholder="Enter menu item description..."
                rows={3}
                maxLength={500}
                showCount
              />
            </Form.Item>

            {/* Image URL */}
            <Form.Item
              label="Image URL"
              name="imageUrl"
              rules={[
                { type: 'url', message: 'Please enter a valid URL' },
                { max: 500, message: 'URL must be at most 500 characters' },
              ]}
            >
              <Input
                placeholder="https://example.com/image.jpg"
                size="large"
                maxLength={500}
              />
            </Form.Item>

            {/* Calories */}
            <Form.Item
              label="Calories (optional)"
              name="calories"
            >
              <InputNumber
                placeholder="e.g., 350"
                size="large"
                style={{ width: '100%' }}
                min={0}
                step={10}
              />
            </Form.Item>

            {/* Is Active */}
            <Form.Item
              label="Status"
              name="isActive"
              valuePropName="checked"
            >
              <Switch
                checkedChildren="Active"
                unCheckedChildren="Inactive"
              />
            </Form.Item>
          </Form>
        </Spin>
      </Modal>
    </>
  );
}
