'use client';

// components/stores/StoreModal.tsx
// Reusable modal for creating and editing stores

import React, { useEffect, useState } from 'react';
import { Modal, Form, Input, Select, Switch, message } from 'antd';

const { Option } = Select;

interface StoreModalProps {
  visible: boolean;
  mode: 'create' | 'edit';
  store?: any;
  onClose: () => void;
  onSuccess: () => void;
}

export default function StoreModal({
  visible,
  mode,
  store,
  onClose,
  onSuccess,
}: StoreModalProps) {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [restaurants, setRestaurants] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [messageApi, contextHolder] = message.useMessage();

  // Fetch restaurants and locations
  useEffect(() => {
    if (visible) {
      fetchRestaurants();
      fetchLocations();
    }
  }, [visible]);

  // Set form values when editing
  useEffect(() => {
    if (mode === 'edit' && store) {
      form.setFieldsValue({
        restaurantId: store.restaurant.restaurantId,
        locationId: store.location.locationId,
        address: store.address,
        phonePrimary: store.phonePrimary,
        phoneSecondary: store.phoneSecondary,
        isAiAgentEnabled: store.isAiAgentEnabled,
        timeZone: store.timeZone,
      });
    } else {
      form.resetFields();
      // Set default values for create mode
      form.setFieldsValue({
        isAiAgentEnabled: true,
        timeZone: 'America/Toronto',
      });
    }
  }, [mode, store, visible]);

  const fetchRestaurants = async () => {
    try {
      const response = await fetch('/api/restaurants');
      const data = await response.json();
      if (response.ok && data.success) {
        setRestaurants(data.restaurants);
      }
    } catch (error) {
      console.error('Fetch restaurants error:', error);
    }
  };

  const fetchLocations = async () => {
    try {
      const response = await fetch('/api/locations');
      const data = await response.json();
      if (response.ok && data.success) {
        setLocations(data.locations);
      }
    } catch (error) {
      console.error('Fetch locations error:', error);
    }
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      let response;
      if (mode === 'create') {
        response = await fetch('/api/stores/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(values),
        });
      } else {
        response = await fetch(`/api/stores/${store.storeId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(values),
        });
      }

      const data = await response.json();

      if (response.ok && data.success) {
        messageApi.success(
          mode === 'create'
            ? 'Store created successfully!'
            : 'Store updated successfully!'
        );
        form.resetFields();
        onSuccess();
        onClose();
      } else {
        messageApi.error(data.error || 'Operation failed');
      }
    } catch (error) {
      console.error('Submit error:', error);
      messageApi.error('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    form.resetFields();
    onClose();
  };

  const timeZones = [
    'America/Toronto',
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Los_Angeles',
    'America/Vancouver',
    'America/Edmonton',
    'America/Winnipeg',
    'America/Halifax',
  ];

  return (
    <>
      {contextHolder}
      <Modal
        title={mode === 'create' ? 'Create New Store' : 'Edit Store'}
        open={visible}
        onOk={handleSubmit}
        onCancel={handleCancel}
        confirmLoading={loading}
        width={600}
        okText={mode === 'create' ? 'Create' : 'Update'}
      >
        <Form
          form={form}
          layout="vertical"
          style={{ marginTop: 24 }}
        >
          <Form.Item
            name="restaurantId"
            label="Restaurant"
            rules={[{ required: true, message: 'Please select a restaurant' }]}
          >
            <Select
              placeholder="Select restaurant"
              size="large"
              disabled={mode === 'edit'} // Can't change restaurant when editing
            >
              {restaurants.map((restaurant) => (
                <Option key={restaurant.restaurantId} value={restaurant.restaurantId}>
                  {restaurant.name}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item
            name="locationId"
            label="Location"
            rules={[{ required: true, message: 'Please select a location' }]}
          >
            <Select placeholder="Select location" size="large">
              {locations.map((location) => (
                <Option key={location.locationId} value={location.locationId}>
                  {location.name}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item
            name="address"
            label="Address"
            rules={[{ required: true, message: 'Please enter the address' }]}
          >
            <Input.TextArea
              placeholder="Enter full address"
              rows={3}
              size="large"
            />
          </Form.Item>

          <Form.Item
            name="phonePrimary"
            label="Primary Phone"
            rules={[
              { required: true, message: 'Please enter primary phone number' },
            ]}
          >
            <Input placeholder="+1 (416) 555-0100" size="large" />
          </Form.Item>

          <Form.Item name="phoneSecondary" label="Secondary Phone">
            <Input placeholder="+1 (416) 555-0101 (optional)" size="large" />
          </Form.Item>

          <Form.Item name="timeZone" label="Time Zone">
            <Select placeholder="Select time zone" size="large">
              {timeZones.map((tz) => (
                <Option key={tz} value={tz}>
                  {tz}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item
            name="isAiAgentEnabled"
            label="AI Agent"
            valuePropName="checked"
          >
            <Switch
              checkedChildren="Enabled"
              unCheckedChildren="Disabled"
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
}
